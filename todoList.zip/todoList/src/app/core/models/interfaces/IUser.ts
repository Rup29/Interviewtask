export interface InewTasks{
      name:string,
      status:string,
      date:number,
      priority:string,
      comments:string,
}   