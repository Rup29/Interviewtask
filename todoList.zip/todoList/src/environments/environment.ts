

export const environment = {
   production: true,
   //  api:"http://localhost:8080/api/user/"
 api:"http://localhost:3000/"
};


