export const APIConstant = {
       list:{
         tasklist:"user",
       }   
}